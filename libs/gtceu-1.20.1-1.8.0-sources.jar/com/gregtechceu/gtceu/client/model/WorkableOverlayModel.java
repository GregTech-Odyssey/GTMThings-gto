package com.gregtechceu.gtceu.client.model;

import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.client.util.StaticFaceBakery;
import com.gregtechceu.gtceu.config.ConfigHolder;
import com.gregtechceu.gtceu.utils.GTUtil;

import com.lowdragmc.lowdraglib.client.model.ModelFactory;
import com.lowdragmc.lowdraglib.client.renderer.IItemRendererProvider;
import com.lowdragmc.lowdraglib.utils.ResourceHelper;

import net.minecraft.MethodsReturnNonnullByDefault;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.texture.MissingTextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.BlockModelRotation;
import net.minecraft.client.resources.model.ModelState;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import com.mojang.blaze3d.vertex.PoseStack;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Consumer;

import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
public class WorkableOverlayModel {

    public enum OverlayFace {

        FRONT,
        BACK,
        TOP,
        BOTTOM,
        SIDE;

        public static final OverlayFace[] VALUES = values();

        public static OverlayFace bySide(Direction side) {
            return switch (side) {
                case DOWN -> BOTTOM;
                case UP -> TOP;
                case NORTH -> FRONT;
                case SOUTH -> BACK;
                case WEST, EAST -> SIDE;
            };
        }
    }

    protected final ResourceLocation location;

    @OnlyIn(Dist.CLIENT)
    public Map<OverlayFace, ActivePredicate> sprites;

    @OnlyIn(Dist.CLIENT)
    public static class ActivePredicate {

        private final ResourceLocation normalSprite;
        private final ResourceLocation activeSprite;
        private final ResourceLocation pausedSprite;

        private final ResourceLocation normalSpriteEmissive;
        private final ResourceLocation activeSpriteEmissive;
        private final ResourceLocation pausedSpriteEmissive;

        public ActivePredicate(@Nullable ResourceLocation normalSprite,
                               @Nullable ResourceLocation activeSprite,
                               @Nullable ResourceLocation pausedSprite,
                               @Nullable ResourceLocation normalSpriteEmissive,
                               @Nullable ResourceLocation activeSpriteEmissive,
                               @Nullable ResourceLocation pausedSpriteEmissive) {
            this.normalSprite = normalSprite;
            this.activeSprite = activeSprite;
            this.pausedSprite = pausedSprite;
            this.normalSpriteEmissive = normalSpriteEmissive;
            this.activeSpriteEmissive = activeSpriteEmissive;
            this.pausedSpriteEmissive = pausedSpriteEmissive;
        }

        @Nullable
        public TextureAtlasSprite getSprite(boolean active, boolean workingEnabled) {
            return getTextureAtlasSprite(active, workingEnabled, activeSprite, pausedSprite, normalSprite);
        }

        @Nullable
        public TextureAtlasSprite getEmissiveSprite(boolean active, boolean workingEnabled) {
            return getTextureAtlasSprite(active, workingEnabled, activeSpriteEmissive, pausedSpriteEmissive,
                    normalSpriteEmissive);
        }

        @Nullable
        private TextureAtlasSprite getTextureAtlasSprite(boolean active, boolean workingEnabled,
                                                         @Nullable ResourceLocation activeSprite,
                                                         @Nullable ResourceLocation pausedSprite,
                                                         @Nullable ResourceLocation normalSprite) {
            if (active) {
                if (workingEnabled) {
                    return activeSprite == null ? null : ModelFactory.getBlockSprite(activeSprite);
                } else {
                    return pausedSprite == null ? null : ModelFactory.getBlockSprite(pausedSprite);
                }
            }
            return normalSprite == null ? null : ModelFactory.getBlockSprite(normalSprite);
        }
    }

    public WorkableOverlayModel(ResourceLocation location) {
        this.location = location;
        if (GTCEu.isClientSide()) {
            this.sprites = new EnumMap<>(OverlayFace.class);
        }
    }

    @OnlyIn(Dist.CLIENT)
    public List<BakedQuad> bakeQuads(@Nullable Direction side, ModelState modelState,
                                     boolean isActive, boolean isWorkingEnabled) {
        var quads = new ArrayList<BakedQuad>();

        for (var renderSide : GTUtil.DIRECTIONS) {
            ActivePredicate predicate = sprites.get(OverlayFace.bySide(renderSide));
            if (predicate != null) {
                var texture = predicate.getSprite(isActive, isWorkingEnabled);
                if (texture != null) {
                    var quad = StaticFaceBakery.bakeFace(StaticFaceBakery.SLIGHTLY_OVER_BLOCK, renderSide, texture,
                            modelState, -1, 0, true, true);
                    if (quad.getDirection() == side) {
                        quads.add(quad);
                    }
                }

                texture = predicate.getEmissiveSprite(isActive, isWorkingEnabled);
                if (texture != null) {
                    BakedQuad quad;
                    if (ConfigHolder.INSTANCE.client.machinesEmissiveTextures) {
                        quad = StaticFaceBakery.bakeFace(StaticFaceBakery.SLIGHTLY_OVER_BLOCK, renderSide, texture,
                                modelState, -101, 15, true, false);
                    } else {
                        quad = StaticFaceBakery.bakeFace(StaticFaceBakery.SLIGHTLY_OVER_BLOCK, renderSide, texture,
                                modelState, -1, 0, true, true);
                    }
                    if (quad.getDirection() == side) {
                        quads.add(quad);
                    }
                }
            }
        }
        return quads;
    }

    @OnlyIn(Dist.CLIENT)
    public TextureAtlasSprite getParticleTexture() {
        for (ActivePredicate predicate : sprites.values()) {
            TextureAtlasSprite sprite = predicate.getSprite(false, false);
            if (sprite != null) return sprite;
        }
        return ModelFactory.getBlockSprite(MissingTextureAtlasSprite.getLocation());
    }

    @OnlyIn(Dist.CLIENT)
    public void renderItem(ItemStack stack, ItemDisplayContext transformType, boolean leftHand, PoseStack matrixStack,
                           MultiBufferSource buffer, int combinedLight, int combinedOverlay, BakedModel model) {
        IItemRendererProvider.disabled.set(true);
        Minecraft.getInstance().getItemRenderer().render(stack, transformType, leftHand, matrixStack, buffer,
                combinedLight, combinedOverlay,
                (ItemBakedModel) (state, direction, random) -> bakeQuads(direction, BlockModelRotation.X0_Y0,
                        false, false));
        IItemRendererProvider.disabled.set(false);
    }

    @OnlyIn(Dist.CLIENT)
    public void registerTextureAtlas(Consumer<ResourceLocation> register) {
        sprites.clear();
        for (OverlayFace overlayFace : OverlayFace.VALUES) {
            final String overlayPath = "/overlay_" + overlayFace.name().toLowerCase(Locale.ROOT);

            var normalSprite = ResourceLocation.fromNamespaceAndPath(location.getNamespace(), location.getPath() + overlayPath);
            var normalSprite1 = getTextureLocation(normalSprite);
            if (!ResourceHelper.isResourceExist(normalSprite1)) continue;
            register.accept(normalSprite);

            // normal
            final String active = String.format("%s_active", overlayPath);
            ResourceLocation activeSprite = ResourceLocation.fromNamespaceAndPath(location.getNamespace(), location.getPath() + active);
            var activeSprite1 = getTextureLocation(activeSprite);
            if (ResourceHelper.isResourceExist(activeSprite1)) register.accept(activeSprite);
            else activeSprite = normalSprite;

            final String paused = String.format("%s_paused", overlayPath);
            ResourceLocation pausedSprite = ResourceLocation.fromNamespaceAndPath(location.getNamespace(), location.getPath() + paused);
            var pausedSprite1 = getTextureLocation(pausedSprite);
            if (ResourceHelper.isResourceExist(pausedSprite1)) register.accept(pausedSprite);
            else pausedSprite = normalSprite;

            // emissive
            ResourceLocation normalSpriteEmissive = ResourceLocation.fromNamespaceAndPath(location.getNamespace(),
                    location.getPath() + overlayPath + "_emissive");
            var normalSpriteEmissive1 = getTextureLocation(normalSpriteEmissive);
            if (ResourceHelper.isResourceExist(normalSpriteEmissive1)) register.accept(normalSpriteEmissive);
            else normalSpriteEmissive = null;

            ResourceLocation activeSpriteEmissive = ResourceLocation.fromNamespaceAndPath(location.getNamespace(),
                    location.getPath() + active + "_emissive");
            var activeSpriteEmissive1 = getTextureLocation(activeSpriteEmissive);
            if (ResourceHelper.isResourceExist(activeSpriteEmissive1)) register.accept(activeSpriteEmissive);
            else activeSpriteEmissive = null;

            ResourceLocation pausedSpriteEmissive = ResourceLocation.fromNamespaceAndPath(location.getNamespace(),
                    location.getPath() + paused + "_emissive");
            var pausedSpriteEmissive1 = getTextureLocation(pausedSpriteEmissive);
            if (ResourceHelper.isResourceExist(pausedSpriteEmissive1)) register.accept(pausedSpriteEmissive);
            else pausedSpriteEmissive = null;

            sprites.put(overlayFace, new ActivePredicate(normalSprite, activeSprite, pausedSprite,
                    normalSpriteEmissive, activeSpriteEmissive, pausedSpriteEmissive));
        }
    }

    private ResourceLocation getTextureLocation(ResourceLocation location) {
        return ResourceLocation.fromNamespaceAndPath(location.getNamespace(), "textures/%s.png".formatted(location.getPath()));
    }
}
