package com.gregtechceu.gtceu.api.registry.registrate.forge;

import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.api.data.chemical.material.Material;
import com.gregtechceu.gtceu.api.fluids.FluidState;
import com.gregtechceu.gtceu.api.fluids.GTFluid;
import com.gregtechceu.gtceu.api.fluids.forge.GTFluidImpl;
import com.gregtechceu.gtceu.api.item.GTBucketItem;
import com.gregtechceu.gtceu.api.registry.registrate.IGTFluidBuilder;
import com.gregtechceu.gtceu.utils.GTUtil;

import net.minecraft.MethodsReturnNonnullByDefault;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.Fluid;
import net.minecraftforge.client.extensions.common.IClientFluidTypeExtensions;
import net.minecraftforge.common.SoundActions;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.FluidType;
import net.minecraftforge.registries.ForgeRegistries;

import com.google.common.base.Preconditions;
import com.gto.registrate.AbstractRegistrate;
import com.gto.registrate.ClientEvent;
import com.gto.registrate.builders.AbstractBuilder;
import com.gto.registrate.builders.BlockBuilder;
import com.gto.registrate.builders.ItemBuilder;
import com.gto.registrate.providers.ProviderType;
import com.gto.registrate.providers.RegistrateTagsProvider;
import com.gto.registrate.util.entry.RegistryEntry;
import com.gto.registrate.util.nullness.NonNullBiConsumer;
import com.gto.registrate.util.nullness.NonNullBiFunction;
import com.gto.registrate.util.nullness.NonNullConsumer;
import com.gto.registrate.util.nullness.NonNullSupplier;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

import javax.annotation.ParametersAreNonnullByDefault;

@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
public class GTFluidBuilder<P> extends AbstractBuilder<Fluid, GTFluidImpl.Flowing, P, GTFluidBuilder<P>> implements IGTFluidBuilder {

    public int temperature = 300;
    public int density = 1000;
    public int luminance = 0;
    public int viscosity = 1000;
    public int color = -1;
    public int burnTime = -1;
    public FluidState state;

    @FunctionalInterface
    public interface FluidTypeFactory {

        FluidType create(String langKey, Material material, FluidType.Properties properties, ResourceLocation stillTexture, ResourceLocation flowingTexture, int color);
    }

    private final String sourceName;
    private final String bucketName;
    private final Material material;
    private final String langKey;
    private final ResourceLocation stillTexture;
    private final ResourceLocation flowingTexture;
    @Nullable
    private final NonNullSupplier<FluidType> fluidType;
    @Nullable
    private Boolean defaultSource;
    @Nullable
    private Boolean defaultBlock;
    @Nullable
    private Boolean defaultBucket;
    private NonNullConsumer<FluidType.Properties> typeProperties = $ -> {};

    private boolean registerType;
    @Nullable
    private NonNullSupplier<? extends GTFluid> source;
    @Nullable
    private NonNullSupplier<? extends LiquidBlock> block;
    @Nullable
    private NonNullSupplier<? extends BucketItem> bucket;
    private final List<TagKey<Fluid>> tags = new ArrayList<>();

    public GTFluidBuilder(AbstractRegistrate<?> owner, P parent, Material material, String name, String langKey, ResourceLocation stillTexture, ResourceLocation flowingTexture, GTFluidBuilder.FluidTypeFactory typeFactory) {
        super(owner, parent, "flowing_" + name, ForgeRegistries.Keys.FLUIDS);
        this.sourceName = name;
        this.bucketName = name + "_bucket";
        this.material = material;
        this.langKey = langKey;
        this.stillTexture = stillTexture;
        this.flowingTexture = flowingTexture;
        this.fluidType = NonNullSupplier.lazy(() -> typeFactory.create(langKey, material, makeTypeProperties(), this.stillTexture, this.flowingTexture, this.color));
        this.registerType = true;
        defaultBucket();
    }

    public GTFluidBuilder<P> defaultLang() {
        return lang(f -> f.getFluidType().getDescriptionId(), langKey);
    }

    public GTFluidBuilder<P> lang(String name) {
        return lang(f -> f.getFluidType().getDescriptionId(), name);
    }

    public GTFluidBuilder<P> renderType(Supplier<RenderType> layer) {
        if (GTCEu.isClientSide()) {
            ClientEvent.setFluidRenderLayer(asSupplier(), layer);
        }
        return this;
    }

    public GTFluidBuilder<P> defaultSource() {
        if (this.defaultSource != null) {
            throw new IllegalStateException("Cannot set a default source after a custom source has been created");
        }
        this.defaultSource = true;
        return this;
    }

    public GTFluidBuilder<P> source(NonNullSupplier<? extends GTFluid> factory) {
        this.defaultSource = false;
        this.source = NonNullSupplier.lazy(factory);
        return this;
    }

    public GTFluidBuilder<P> defaultBlock() {
        if (this.defaultBlock != null) {
            throw new IllegalStateException("Cannot set a default block after a custom block has been created");
        }
        this.defaultBlock = true;
        return this;
    }

    public BlockBuilder<LiquidBlock, GTFluidBuilder<P>> block() {
        return block(LiquidBlock::new);
    }

    public <B extends LiquidBlock> BlockBuilder<B, GTFluidBuilder<P>> block(NonNullBiFunction<NonNullSupplier<GTFluidImpl.Flowing>, BlockBehaviour.Properties, ? extends B> factory) {
        if (this.defaultBlock == Boolean.FALSE) {
            throw new IllegalStateException("Only one call to block/noBlock per builder allowed");
        }
        NonNullSupplier<GTFluidImpl.Flowing> supplier = asSupplier();
        return getOwner().<B, GTFluidBuilder<P>>block(this, sourceName, p -> factory.apply(supplier, p)).properties(p -> BlockBehaviour.Properties.copy(Blocks.WATER).noLootTable()).properties(p -> p.lightLevel(blockState -> fluidType.get().getLightLevel())).properties(p -> p.mapColor(GTUtil.determineMapColor(material.getMaterialRGB()))).setData(ProviderType.LANG, NonNullBiConsumer.noop()).blockstate((ctx, prov) -> prov.simpleBlock(ctx.getEntry(), prov.models().getBuilder(sourceName).texture("particle", stillTexture))).onRegister(block -> this.block = () -> block);
    }

    public GTFluidBuilder<P> noBlock() {
        if (this.defaultBlock == Boolean.FALSE) {
            throw new IllegalStateException("Only one call to block/noBlock per builder allowed");
        }
        this.defaultBlock = false;
        return this;
    }

    public GTFluidBuilder<P> noBucket() {
        if (this.defaultBucket == Boolean.FALSE) {
            throw new IllegalStateException("Only one call to bucket/noBucket per builder allowed");
        }
        this.defaultBucket = false;
        return this;
    }

    public GTFluidBuilder<P> defaultBucket() {
        if (this.defaultBucket != null) {
            throw new IllegalStateException("Cannot set a default bucket after a custom bucket has been created");
        }
        defaultBucket = true;
        return this;
    }

    public ItemBuilder<GTBucketItem, GTFluidBuilder<P>> bucket() {
        if (this.defaultBucket == Boolean.FALSE) {
            throw new IllegalStateException("Only one call to bucket/noBucket per builder allowed");
        }
        return getOwner().item(this, bucketName, p -> new GTBucketItem(this.source, p, this.material, this.langKey)).properties(p -> p.craftRemainder(Items.BUCKET).stacksTo(1)).color(() -> () -> GTBucketItem::color).setData(ProviderType.LANG, NonNullBiConsumer.noop()).model(NonNullBiConsumer.noop()).onRegister(bucket -> this.bucket = () -> bucket);
    }

    @SafeVarargs
    public final GTFluidBuilder<P> tag(TagKey<Fluid>... tags) {
        GTFluidBuilder<P> ret = this.tag(ProviderType.FLUID_TAGS, tags);
        if (this.tags.isEmpty()) {
            ret.getOwner().<RegistrateTagsProvider<Fluid>, Fluid>setDataGenerator(ret.sourceName, getRegistryKey(), ProviderType.FLUID_TAGS, prov -> this.tags.stream().map(prov::addTag).forEach(p -> p.add(getSource().builtInRegistryHolder().key())));
        }
        this.tags.addAll(Arrays.asList(tags));
        return ret;
    }

    private GTFluid getSource() {
        NonNullSupplier<? extends GTFluid> source = this.source;
        Preconditions.checkNotNull(source, "Fluid has no source block: " + sourceName);
        return source.get();
    }

    private FluidType.Properties makeTypeProperties() {
        FluidType.Properties properties = FluidType.Properties.create();
        this.typeProperties.accept(properties);
        properties.descriptionId(langKey);
        setData(ProviderType.LANG, NonNullBiConsumer.noop());
        return properties.sound(SoundActions.BUCKET_FILL, SoundEvents.BUCKET_FILL).sound(SoundActions.BUCKET_EMPTY, SoundEvents.BUCKET_EMPTY).temperature(temperature).density(density).viscosity(viscosity).lightLevel(luminance);
    }

    @Override
    protected GTFluidImpl.Flowing createEntry() {
        return new GTFluidImpl.Flowing(this.state, this.source, this.asSupplier(), (() -> this.block != null ? this.block.get() : null), (() -> this.bucket != null ? this.bucket.get() : null), this.burnTime, this.fluidType);
    }

    @Override
    public GTFluidBuilder<P> hasBlock(boolean hasBlock) {
        if (hasBlock && defaultBlock == null) {
            defaultBlock();
        }
        if (!hasBlock && defaultBlock != null) {
            noBlock();
        }
        return this;
    }

    @Override
    public IGTFluidBuilder hasBucket(boolean hasBucket) {
        if (hasBucket && defaultBucket == null) {
            defaultBucket();
        }
        if (!hasBucket && defaultBucket != null) {
            noBucket();
        }
        return this;
    }

    @Override
    public IGTFluidBuilder onFluidRegister(Consumer<Fluid> fluidConsumer) {
        return onRegister(fluidConsumer::accept);
    }

    @Override
    public RegistryEntry<GTFluidImpl.Flowing> register() {
        // Check the fluid has a type.
        if (this.fluidType != null) {
            // Register the type.
            if (this.registerType) {
                getOwner().simple(this, this.sourceName, ForgeRegistries.Keys.FLUID_TYPES, this.fluidType);
            }
        } else {
            throw new IllegalStateException("Fluid must have a type: " + getName());
        }
        if (defaultSource == Boolean.TRUE) {
            source(() -> new GTFluidImpl.Source(this.state, this.source, this.asSupplier(), (() -> this.block != null ? this.block.get() : null), (() -> this.bucket != null ? this.bucket.get() : null), this.burnTime, this.fluidType));
        }
        if (defaultBlock == Boolean.TRUE) {
            block().register();
        }
        if (defaultBucket == Boolean.TRUE) {
            bucket().register();
        }
        NonNullSupplier<? extends GTFluid> source = this.source;
        if (source != null) {
            getOwner().register(sourceName, ForgeRegistries.Keys.FLUIDS, source);
        } else {
            throw new IllegalStateException("Fluid must have a source version: " + getName());
        }
        return super.register();
    }

    @Override
    public Supplier<? extends Fluid> registerFluid() {
        register();
        return this.source;
    }

    public static FluidType defaultFluidType(String langKey, Material material, FluidType.Properties properties, ResourceLocation stillTexture, ResourceLocation flowingTexture, int color) {
        return new FluidType(properties) {

            @Override
            public void initializeClient(Consumer<IClientFluidTypeExtensions> consumer) {
                consumer.accept(new GTClientFluidTypeExtensions(stillTexture, flowingTexture, color));
            }

            @Override
            public String getDescriptionId() {
                return material.getUnlocalizedName();
            }

            @Override
            public Component getDescription() {
                return Component.translatable(langKey, material.getLocalizedName());
            }

            @Override
            public Component getDescription(FluidStack stack) {
                return this.getDescription();
            }
        };
    }

    /**
     * @return {@code this}.
     */
    public GTFluidBuilder<P> temperature(final int temperature) {
        this.temperature = temperature;
        return this;
    }

    /**
     * @return {@code this}.
     */
    public GTFluidBuilder<P> density(final int density) {
        this.density = density;
        return this;
    }

    /**
     * @return {@code this}.
     */
    public GTFluidBuilder<P> luminance(final int luminance) {
        this.luminance = luminance;
        return this;
    }

    /**
     * @return {@code this}.
     */
    public GTFluidBuilder<P> viscosity(final int viscosity) {
        this.viscosity = viscosity;
        return this;
    }

    /**
     * @return {@code this}.
     */
    public GTFluidBuilder<P> color(final int color) {
        this.color = color;
        return this;
    }

    /**
     * @return {@code this}.
     */
    public GTFluidBuilder<P> burnTime(final int burnTime) {
        this.burnTime = burnTime;
        return this;
    }

    /**
     * @return {@code this}.
     */
    public GTFluidBuilder<P> state(final FluidState state) {
        this.state = state;
        return this;
    }
}
