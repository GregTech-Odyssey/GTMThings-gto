package com.gregtechceu.gtceu.api.capability;

import com.gregtechceu.gtceu.api.machine.feature.IMachineFeature;

import net.minecraft.core.Direction;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface IOpticalComputationHatch extends IOpticalComputationProvider, IMachineFeature {

    boolean isTransmitter();

    boolean testCapability(@Nullable Direction side);

    @Override
    default @Nullable <T> T getGTCapability(@NotNull Class<T> cap, @Nullable Direction side) {
        if (cap == GTCapability.COMPUTATION_PROVIDER && testCapability(side)) {
            return cap.cast(this);
        }
        return null;
    }
}
