package com.gregtechceu.gtceu.api.fluids;

import com.gregtechceu.gtceu.utils.memoization.GTMemoizer;

import net.minecraft.MethodsReturnNonnullByDefault;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;

import lombok.Getter;

import java.util.function.Supplier;

import javax.annotation.ParametersAreNonnullByDefault;

@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
public abstract class GTFluid extends FlowingFluid {

    @Getter
    private final FluidState state;
    private final Supplier<Item> bucketItem;
    private final Supplier<Fluid> stillFluid;
    private final Supplier<Fluid> flowingFluid;
    private final Supplier<Block> block;
    @Getter
    private final int burnTime;

    public GTFluid(FluidState state, Supplier<? extends Fluid> still, Supplier<? extends Fluid> flowing, Supplier<? extends LiquidBlock> block, Supplier<? extends Item> bucket, int burnTime) {
        super();
        this.state = state;
        this.stillFluid = GTMemoizer.memoize(() -> still.get() != null ? still.get() : Fluids.EMPTY);
        this.flowingFluid = GTMemoizer.memoize(() -> flowing.get() != null ? flowing.get() : Fluids.EMPTY);
        this.block = GTMemoizer.memoize(block::get);
        this.bucketItem = GTMemoizer.memoize(() -> bucket.get() != null ? bucket.get() : Items.AIR);
        this.burnTime = burnTime;
    }

    @Override
    protected boolean canBeReplacedWith(net.minecraft.world.level.material.FluidState state, BlockGetter level, BlockPos pos, Fluid fluid, Direction direction) {
        return direction == Direction.DOWN && !isSame(fluid);
    }

    @Override
    public int getTickDelay(LevelReader level) {
        return 5;
    }

    @Override
    protected float getExplosionResistance() {
        return 10;
    }

    @Override
    protected int getSlopeFindDistance(LevelReader level) {
        return 4;
    }

    @Override
    protected int getDropOff(LevelReader level) {
        return 1;
    }

    @Override
    protected BlockState createLegacyBlock(net.minecraft.world.level.material.FluidState state) {
        var block = this.block.get();
        if (block != null) return block.defaultBlockState().setValue(LiquidBlock.LEVEL, getLegacyLevel(state));
        return Blocks.AIR.defaultBlockState();
    }

    @Override
    public Fluid getFlowing() {
        return flowingFluid.get();
    }

    @Override
    public Fluid getSource() {
        return stillFluid.get();
    }

    @Override
    public Item getBucket() {
        return bucketItem != null && bucketItem.get() != null ? bucketItem.get() : Items.AIR;
    }

    @Override
    protected boolean canConvertToSource(Level world) {
        return false;
    }

    @Override
    protected void beforeDestroyingBlock(LevelAccessor level, BlockPos pos, BlockState state) {
        BlockEntity blockEntity = state.hasBlockEntity() ? level.getBlockEntity(pos) : null;
        Block.dropResources(state, level, pos, blockEntity);
    }

    @Override
    public boolean isSame(Fluid fluid) {
        boolean still = this.getSource() == fluid;
        boolean flowing = this.getFlowing() == fluid;
        return still || flowing;
    }
}
