package com.gregtechceu.gtceu.api.recipe.extension;

import com.gregtechceu.gtceu.api.machine.feature.IComputationContainerMachine;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gregtechceu.gtceu.api.recipe.GTRecipeDefinition;
import com.gregtechceu.gtceu.api.recipe.handler.IO;
import com.gregtechceu.gtceu.api.recipe.handler.IRecipeHandlerHolder;
import com.gregtechceu.gtceu.api.recipe.handler.RecipeHandlerUnit;
import com.gregtechceu.gtceu.common.data.GTRecipeDataKeys;
import com.gregtechceu.gtceu.utils.FormattingUtil;

import com.lowdragmc.lowdraglib.gui.widget.LabelWidget;
import com.lowdragmc.lowdraglib.gui.widget.WidgetGroup;
import com.lowdragmc.lowdraglib.utils.LocalizationUtils;

import net.minecraft.network.chat.Component;

import com.fast.recipesearch.IntLongMap;
import com.gto.datasynclib.DataSyncCodec;
import org.apache.commons.lang3.mutable.MutableInt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class CWUTRecipeExtension extends RecipeExtension<Long> {

    public static final CWUTRecipeExtension INSTANCE = new CWUTRecipeExtension();

    private CWUTRecipeExtension() {
        super("cwut", DataSyncCodec.LONG_CODEC, true);
    }

    @Override
    public boolean handle(IO io, @NotNull IRecipeHandlerHolder holder, @Nullable RecipeHandlerUnit unit, @NotNull GTRecipe recipe, boolean simulate) {
        var cwu = recipe.getInputCWUt();
        if (cwu < 1) return true;
        boolean result;
        if (holder instanceof IComputationContainerMachine machine) {
            result = machine.requestCWU(cwu, simulate) >= cwu;
        } else {
            result = false;
        }
        if (result) return true;
        holder.setIdleReason(() -> Component.translatable("gtceu.multiblock.computation.not_enough_computation"));
        return false;
    }

    @Override
    public void extractInput(GTRecipeDefinition recipe, IntLongMap map) {}

    @Override
    public long getParallel(IRecipeHandlerHolder holder, RecipeHandlerUnit unit, GTRecipe recipe, long parallel) {
        var cwu = recipe.getInputCWUt();
        if (cwu < 1) return parallel;
        if (holder instanceof IComputationContainerMachine machine) {
            parallel = Math.min(parallel, machine.requestCWU(Long.MAX_VALUE, true) / cwu);
        } else {
            parallel = 0;
        }
        if (parallel > 0) return parallel;
        holder.setIdleReason(() -> Component.translatable("gtceu.multiblock.computation.not_enough_computation"));
        return 0;
    }

    @Override
    public void setParallel(GTRecipe recipe, long parallel) {
        var cwu = recipe.getInputCWUt();
        if (cwu < 1) return;
        recipe.setCWUt(cwu * parallel);
    }

    @Override
    public void addInfo(GTRecipeDefinition recipe, WidgetGroup group, int xOffset, MutableInt yOffset) {
        group.addWidget(new LabelWidget(3 - xOffset, yOffset.addAndGet(10),
                LocalizationUtils.format("gtceu.recipe.computation_per_tick", FormattingUtil.formatNumbers(recipe.data.getLong(GTRecipeDataKeys.CWUT)))));
        if (recipe.data.getBoolean(GTRecipeDataKeys.DURATION_IS_TOTAL_CWU)) {
            group.addWidget(new LabelWidget(3 - xOffset, yOffset.addAndGet(10),
                    LocalizationUtils.format("gtceu.recipe.total_computation", FormattingUtil.formatNumbers(recipe.duration))));
        }
    }

    @Override
    public int getInfoHeight(GTRecipeDefinition recipe) {
        return 10;
    }
}
