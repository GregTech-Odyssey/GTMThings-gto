package com.gregtechceu.gtceu.api;

import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.api.addon.AddonFinder;
import com.gregtechceu.gtceu.api.addon.IGTAddon;
import com.gregtechceu.gtceu.api.block.ICoilType;
import com.gregtechceu.gtceu.api.block.IFilterType;
import com.gregtechceu.gtceu.api.data.chemical.material.IMaterialRegistryManager;
import com.gregtechceu.gtceu.api.machine.multiblock.IBatteryData;
import com.gregtechceu.gtceu.common.block.BatteryBlock;
import com.gregtechceu.gtceu.common.block.CoilBlock;
import com.gregtechceu.gtceu.config.ConfigHolder;

import net.minecraft.world.level.block.Block;

import it.unimi.dsi.fastutil.objects.Reference2ReferenceOpenHashMap;
import org.jetbrains.annotations.ApiStatus;

import java.util.Map;
import java.util.function.Supplier;

public class GTCEuAPI {

    /**
     * Will be available at the Construction stage
     */
    public static IMaterialRegistryManager materialManager;
    /**
     * Will be available at the Pre-Initialization stage
     */
    private static boolean highTier;
    private static boolean highTierInitialized;
    public static final Map<ICoilType, Supplier<CoilBlock>> HEATING_COILS = new Reference2ReferenceOpenHashMap<>();
    public static final Map<IFilterType, Supplier<Block>> CLEANROOM_FILTERS = new Reference2ReferenceOpenHashMap<>();
    public static final Map<IBatteryData, Supplier<BatteryBlock>> PSS_BATTERIES = new Reference2ReferenceOpenHashMap<>();

    /**
     * Initializes High-Tier. Internal use only, do not attempt to call this.
     */
    @ApiStatus.Internal
    public static void initializeHighTier() {
        if (highTierInitialized) throw new IllegalStateException("High-Tier is already initialized.");
        highTier = ConfigHolder.INSTANCE.machines.highTierContent || AddonFinder.getAddons().stream().anyMatch(IGTAddon::requiresHighTier) || GTCEu.isDev();
        highTierInitialized = true;
        if (isHighTier()) GTCEu.LOGGER.info("High-Tier is Enabled.");
        else GTCEu.LOGGER.info("High-Tier is Disabled.");
    }

    /**
     * Will be available at the Pre-Initialization stage
     */
    public static boolean isHighTier() {
        return GTCEuAPI.highTier;
    }
}
